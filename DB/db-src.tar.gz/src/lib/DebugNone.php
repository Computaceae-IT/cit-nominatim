<?php

namespace Nominatim;

class Debug
{
    public static function __callStatic($name, $arguments)
    {
        // nothing
    }
}
