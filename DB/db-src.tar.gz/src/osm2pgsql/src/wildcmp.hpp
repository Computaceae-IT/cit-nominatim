#ifndef OSM2PGSQL_WILDCMP_HPP
#define OSM2PGSQL_WILDCMP_HPP

bool wildMatch(char const *wildCard, char const *string);

#endif // OSM2PGSQL_WILDCMP_HPP
