#ifndef OSM2PGSQL_SPROMPT_HPP
#define OSM2PGSQL_SPROMPT_HPP

char *simple_prompt(const char *prompt, int maxlen, int echo);

#endif // OSM2PGSQL_SPROMPT_HPP
