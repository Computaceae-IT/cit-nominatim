
test = { geom_proj = 3857, area_proj = 3857 }

dofile(os.getenv('SRCPATH') .. '/data/test_output_flex_area.lua')

