
test = { type = 'geometry', split_at = 'multi' }

dofile(os.getenv('SRCPATH') .. '/data/test_output_flex_multigeom.lua')

