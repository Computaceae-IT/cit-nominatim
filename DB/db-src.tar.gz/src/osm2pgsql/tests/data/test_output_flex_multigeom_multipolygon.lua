
test = { type = 'multipolygon' }

dofile(os.getenv('SRCPATH') .. '/data/test_output_flex_multigeom.lua')

